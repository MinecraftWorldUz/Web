give @s minecraft:torch 4
