give @s minecraft:torch 16
give @s minecraft:ladder 13
give @s minecraft:bread 10
give @s minecraft:stone_pickaxe 7
