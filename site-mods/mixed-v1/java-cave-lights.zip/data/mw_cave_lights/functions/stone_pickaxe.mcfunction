give @s minecraft:stone_pickaxe 7
