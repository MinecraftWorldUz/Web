give @s minecraft:ladder 5
