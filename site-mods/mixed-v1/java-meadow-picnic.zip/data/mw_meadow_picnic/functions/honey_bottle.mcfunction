give @s minecraft:honey_bottle 5
