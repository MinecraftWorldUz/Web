give @s minecraft:oak_sapling 7
