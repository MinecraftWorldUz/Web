give @s minecraft:dandelion 6
