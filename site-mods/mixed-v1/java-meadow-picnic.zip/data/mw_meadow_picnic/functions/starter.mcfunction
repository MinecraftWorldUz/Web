give @s minecraft:bread 16
give @s minecraft:honey_bottle 13
give @s minecraft:dandelion 10
give @s minecraft:oak_sapling 7
