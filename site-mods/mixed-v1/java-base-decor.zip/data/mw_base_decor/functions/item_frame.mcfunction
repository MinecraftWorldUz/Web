give @s minecraft:item_frame 5
