give @s minecraft:painting 16
give @s minecraft:item_frame 13
give @s minecraft:lantern 10
give @s minecraft:flower_pot 7
