give @s minecraft:lantern 6
