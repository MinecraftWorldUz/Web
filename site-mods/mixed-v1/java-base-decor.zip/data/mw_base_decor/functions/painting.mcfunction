give @s minecraft:painting 4
