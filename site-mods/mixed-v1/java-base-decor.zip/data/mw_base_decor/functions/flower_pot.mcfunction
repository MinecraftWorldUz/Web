give @s minecraft:flower_pot 7
