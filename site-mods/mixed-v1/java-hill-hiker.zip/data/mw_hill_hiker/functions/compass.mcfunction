give @s minecraft:compass 4
