give @s minecraft:compass 16
give @s minecraft:map 13
give @s minecraft:bread 10
give @s minecraft:leather_boots 7
