give @s minecraft:bread 6
