give @s minecraft:leather_boots 7
