give @s minecraft:map 5
